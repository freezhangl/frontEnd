var app = getApp();
var request = require('../api/request.js');
const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

function login(callback = '') {
  var that = this;
  wx.login({
    success: res => {
      if (res.code) {
        // console.log("code=" + res.code);
        request.sendRequest('openid?code=' + res.code, 'GET', {})     //获取openid
          .then(function (response) {
            // console.log(response);
            app.globalData.openid = response.data.data.openid;
            if(typeof(callback)!='string'){
              callback()
            }
          }, function (error) {
            console.log(error);
          });
      } else {

      }

    }
  })
}

module.exports = {
  formatTime: formatTime,
  login: login,
  request:request
}
