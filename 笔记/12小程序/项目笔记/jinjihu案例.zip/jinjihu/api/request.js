var app = getApp();

var sendRequest = function (url, method, data) {    //request请求封装
  var promise = new Promise(function (resolve, reject) {
    wx.request({
      url: "https://jjh.lianzongai.com/api/" + url,
      data: data,
      method: method,
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: resolve,
      fail: reject
    })
  });
  return promise;
};

var sendPutRequest = function (url, method, data, header) {    //request请求封装
  var promise = new Promise(function (resolve, reject) {
    wx.request({
      url: "https://jjh.lianzongai.com/api/" + url,
      data: data,
      method: method,
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: resolve,
      fail: reject
    })
  });
  return promise;
};

var showModal = function (content){
  wx.showModal({
    title: '',
    content: content,
    showCancel: false,
    confirmColor: "#5a70b5",
    success: function (res) {}
  })  
}

module.exports.sendRequest = sendRequest;
module.exports.sendPutRequest = sendPutRequest;
module.exports.showModal = showModal; 
