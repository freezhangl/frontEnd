// pages/detail/detail.js
var app = getApp();
var request = require('../../api/request.js');
Page({

  data: {
    menuList : {}
  },

  onLoad: function (options) {
    this.getmenuList();
  },

  getmenuList: function(){
    var that = this;
    request.sendRequest('store?trading_area_id=' + 1 + '&store_classify_id=' + 1, 'GET', {})     
      .then(function (res) {
        console.log(res);
        var list = res.data.data;
        for (var i = 0; i < res.data.data.length; i++) {      
          list[i].note = res.data.data[i].note.split('|');
          if (list[i].note[0].indexOf("%") == -1) {  //-1时没有%
            list[i].note[0] = list[i].note[0] + '￥'
          } else {
            list[i].note[0] = list[i].note[0].split('%')[0] + '折'
          }
          console.log(list[i].note);
        }

        // list[i].note = [100, '美蛙'];
        // console.log(list[i]);
        
        that.setData({
          menuList: list
        })

      }, function (error) {
        console.log(error);
      });
  },

  onReachBottom: function () {

  },

  onShareAppMessage: function () {

  }
})