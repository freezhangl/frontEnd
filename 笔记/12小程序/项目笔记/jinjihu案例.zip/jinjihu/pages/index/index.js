//index.js
//获取应用实例
var util = require('../../utils/util.js');
var request = require('../../api/request.js');
const app = getApp();

Page({
  data: {
    lunBO: [],
    shangQuan: [],
    message: '',
    message2: '',
    message3: '',
    wxlogin: true,
    getPhone: true,
    text: '验证码',
    yanzheng: 'yanzheng',
    toplogo:'http://pry40x4gs.bkt.clouddn.com/linshi_logo.png'
  },
  onLoad: function () {
    var that = this
    util.login(function callback() {
      // console.log(app.globalData.openid)
      that.login(app.globalData.openid)
    });
    this.getLunBO();
    this.getShangQuan();
  },
  login: function (e) { //登录
    request.sendRequest('login', 'POST', {
      wx_openid: e
    }).then(res => {
      if (res.data.code == 5001) { //没有注册 弹授权 
        this.setData({
          wxlogin: false
        })
        wx.hideTabBar(); //隐藏tabar
      } else if (res.data.code == 200) { //已注册 直接进入页面
        wx.setStorageSync("userInfo", res.data.data)
      }
    })
  },
  register: function () { //注册
    request.sendRequest('register', 'POST', {
      phone: this.data.message2,
      wx_openid: app.globalData.openid,
      wx_img: app.globalData.userInfo.avatarUrl,
      wx_name: app.globalData.userInfo.nickName
    }).then(res => {
      if (res.data.code == 200) {
        console.log('注册成功')
        wx.setStorageSync('userInfo', res.data.data)
        this.setData({
          getPhone: true
        })
        wx.showTabBar() //显示tabar
      } else {
        console.log(res)
      }
    })
  },
  userlogin: function (e) {
    var that = this;
    if (e.detail.userInfo) {
      app.globalData.userInfo = e.detail.userInfo;
      that.setData({
        wxlogin: true,
        getPhone: false //弹出注册手机号
      })
    } else {
      wx.showModal({
        title: '温馨提示',
        content: '需要您的授权，才能正常使用哦~',
        showCancel: false,
        success: function (res) {
          that.setData({
            wxlogin: false
          });
        }
      })
    }
  },
  getLunBO: function () { //请求轮播图
    request.sendRequest('ad', 'GET', {}).then(res => {
      if (res.statusCode == 200) {
        if (res.data.data.length > 0) { //有数据
          this.setData({
            lunBO: res.data.data
          })
          // console.log(this.data)
        }
      }
    })
  },
  getShangQuan: function () { //请求商圈
    request.sendRequest('tradingarea', 'GET', {}).then(res => {
      if (res.statusCode == 200) {
        this.setData({
          shangQuan: res.data.data
        })
        // console.log(this.data)
      }
    })
  },
  goShangQuan: function (e) {
    wx.navigateTo({
      url: '/pages/detail/detail?id='+e.target.dataset.id
    })
  },
  goQiangjuan: function () {
    wx.navigateTo({
      url: '/pages/chaozhi/chaozhi'
    })
  },
  searchHandle: function (e) {
    if (this.data.message.length <= 0) {
      wx.showModal({
        title: '提示',
        content: '您输入为空',
        showCancel: false,
        cancelText: '取消',
        cancelColor: '#000000',
        confirmText: '确定',
        confirmColor: '#3CC51F',
      })
    } else {
      wx.navigateTo({
        url: '/pages/search/search?message=' + this.data.message
      })
    }
  },
  inputHandle: function (e) {
    this.setData({
      message: e.detail.value
    })
  },
  inputHandle2: function (e) {
    this.setData({
      message2: e.detail.value
    })
  },
  inputHandle3: function (e) {
    this.setData({
      message3: e.detail.value
    })
  },
  yanzheng: function () {
    if ((/^1[34578]\d{9}$/.test(this.data.message2))) {
      request.sendRequest('sms?phone=' + this.data.message2, 'GET', {}).then(res => {
        if (res.data.code == 200) {
          console.log('验证码发送成功')
        }
      })
      var time = 60
      this.setData({
        yanzheng: ''
      })
      var timeID = setInterval(() => {
        time--
        this.setData({
          text: time
        })
        if (this.data.text <= 0) {
          clearInterval(timeID)
          this.setData({
            text: '重新发送',
            yanzheng: 'yanzheng'
          })
        }
      }, 1000)
    } else { //手机号不正确
      wx.showModal({
        title: '提示',
        content: '请输入正确的手机号',
        showCancel: false,
        cancelText: '取消',
        cancelColor: '#000000',
        confirmText: '确定',
        confirmColor: '#3CC51F'
      })
    }
  },
  verification: function () {
    if ((/^1[34578]\d{9}$/.test(this.data.message2)) && this.data.message3.length > 0) {
      request.sendRequest('sms', 'POST', {
        phone: this.data.message2,
        code: this.data.message3
      }).then(res => {
        if (res.data.code == 200) {
          this.register()
          // console.log('获取手机号成功')
        } else {
          wx.showModal({
            title: '提示',
            content: res.data.data.message,
            showCancel: false,
            cancelText: '取消',
            cancelColor: '#000000',
            confirmText: '确定',
            confirmColor: '#3CC51F'
          })
        }
        // console.log(res)
      })
    } else { //手机号不正确

    }
  }
})