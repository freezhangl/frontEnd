// pages/search/search.js
const app = getApp();
var util = require('../../utils/util.js');
var request = require('../../api/request.js');
Page({
  data: {
    youhuijuan:[],
    message:'',
    page:0
  },
  onLoad: function (e) {
    // console.log(e)
    this.setData({
      message:e.message
    })
    this.getYouHuiJuan();
  },
  getYouHuiJuan: function () {
    var page1=this.data.page
    page1++
    request.sendRequest('search?page='+page1+'&page_size=10&mod=store_name&v='+this.data.message,'GET',{}).then(res=>{
      if(res.statusCode==200){
        var youhuijuan=this.data.youhuijuan.concat(res.data.data)
         youhuijuan.forEach(item=>{
            var list=item.note.split('|')
            if(list[0].includes('%')){
              list.push('折')
              list[0]= list[0].replace('%','')
            }else{
              list.push('￥')
            }
            item.list=list
          })
        this.setData({
          youhuijuan:youhuijuan,
          page:page1
        })
        wx.hideLoading();
      }
    })
  },
  onReachBottom:function(){
    this.getYouHuiJuan()
    wx.showLoading({
      title: '请稍后'
    });
  },
  useCoupon: function (e) {
    var useID=e.target.dataset.id
    request.sendRequest('coupon/' + e.target.dataset.id, 'POST', {
      user_id: wx.getStorageSync("userInfo").id, 
    }).then(res => {
      if (res.data.code == 200) { //领取成功
        wx.showModal({
          title: '提示',
          content: '领取成功',
          showCancel: false,
          confirmText: '确定',
          confirmColor: '#3CC51F'
        })
        var youhuijuan1=this.data.youhuijuan
        youhuijuan1.forEach(item=>{
            if(item.id==useID){
              item.use=2
            }
          })
        this.setData({
          youhuijuan:youhuijuan1
        })
      } else if (res.data.code == 4005) { //已经领取过
        wx.showModal({
          title: '提示',
          content: '已经领取',
          showCancel: false,
          confirmText: '确定',
          confirmColor: '#3CC51F'
        })
        var youhuijuan1=this.data.youhuijuan
        youhuijuan1.forEach(item=>{
            if(item.id==useID){
              item.use=2
            }
          })
        this.setData({
          youhuijuan:youhuijuan1
        })
      } else if (res.data.code == 4003) { //该优惠券id已下架
        wx.showModal({
          title: '提示',
          content: '该优惠券已下架',
          showCancel: false,
          confirmText: '确定',
          confirmColor: '#3CC51F'
        })
      }
    })
  },
  goUseCoupon:function(e){
    var id=e.target.dataset.id
    console.log('goUseCoupon')
  }
})