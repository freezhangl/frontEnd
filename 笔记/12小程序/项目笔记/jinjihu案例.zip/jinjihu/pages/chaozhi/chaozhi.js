// pages/chaozhi/chaozhi.js
const app = getApp();
var util = require('../../utils/util.js');
var request = require('../../api/request.js');
Page({
  data: {
    youhuijuan: [],
    page: 0
  },
  onLoad: function (options) {
    this.getYouHuiJuan();
  },
  getYouHuiJuan: function () {
    var page1 = this.data.page
    page1++
    request.sendRequest('coupon?mod=2&page=' + page1 + '&page_size=10', 'GET', {}).then(res => {
      if (res.statusCode == 200) {
        if (res.data.data instanceof Array) {
          var youhuijuan=this.data.youhuijuan.concat(res.data.data)
          youhuijuan.forEach(item=>{
            item.use=1
            var list=item.note.split('|')
            if(list[0].includes('%')){
              list.push('折')
              list[0]= list[0].replace('%','')
            }else{
              list.push('￥')
            }
            item.list=list
          })
          this.setData({
            youhuijuan: youhuijuan,
            page: page1
          })
          console.log(youhuijuan)
        }
        wx.hideLoading()
      }
    })
  },
  onReachBottom: function () {
    this.getYouHuiJuan()
    wx.showLoading({
      title: '请稍后'
    });
  },
  useCoupon: function (e) {
    var useID=e.target.dataset.id
    request.sendRequest('coupon/' + e.target.dataset.id, 'POST', {
      user_id: wx.getStorageSync("userInfo").id,   
    }).then(res => {
      if (res.data.code == 200) { //领取成功
        wx.showModal({
          title: '提示',
          content: '领取成功',
          showCancel: false,
          confirmText: '确定',
          confirmColor: '#3CC51F'
        })
        var youhuijuan1=this.data.youhuijuan
        youhuijuan1.forEach(item=>{
            if(item.id==useID){
              item.use=2
            }
          })
        this.setData({
          youhuijuan:youhuijuan1
        })
      } else if (res.data.code == 4005) { //已经领取过
        wx.showModal({
          title: '提示',
          content: '已经领取',
          showCancel: false,
          confirmText: '确定',
          confirmColor: '#3CC51F'
        })
        var youhuijuan1=this.data.youhuijuan
        youhuijuan1.forEach(item=>{
            if(item.id==useID){
              item.use=2
            }
          })
        this.setData({
          youhuijuan:youhuijuan1
        })
      } else if (res.data.code == 4003) { //该优惠券id已下架
        wx.showModal({
          title: '提示',
          content: '该优惠券已下架',
          showCancel: false,
          confirmText: '确定',
          confirmColor: '#3CC51F'
        })
      }
    })
  },
  goUseCoupon:function(e){
    var id=e.target.dataset.id
    console.log('goUseCoupon')
  }
})